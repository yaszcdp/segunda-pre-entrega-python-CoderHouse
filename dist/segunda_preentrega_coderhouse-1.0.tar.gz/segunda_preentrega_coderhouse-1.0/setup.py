from setuptools import setup

setup(
    name="segunda_preentrega_coderhouse", 
    version="1.0", 
    description="Programa de gestión de clientes",
    author="Escobar Tome Yasz", 
    author_email="echidnamun@gmail.com", 
    
    packages=["segunda_preentrega_coderhouse"], 
)